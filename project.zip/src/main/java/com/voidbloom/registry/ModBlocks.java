package com.voidbloom.registry;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.block.RiftPortalBlock;
import com.voidbloom.block.SovereignAltarBlock;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(VoidbloomMod.MODID);

    public static final DeferredBlock<Block> ECHO_STONE = registerWithItem("echo_stone",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE)
                    .strength(2.0F, 6.0F).requiresCorrectToolForDrops().sound(SoundType.DEEPSLATE)));

    public static final DeferredBlock<Block> ECHO_SOIL = registerWithItem("echo_soil",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLUE)
                    .strength(0.8F).sound(SoundType.MOSS)));

    public static final DeferredBlock<Block> ECHO_CRYSTAL_ORE = registerWithItem("echo_crystal_ore",
            () -> new DropExperienceBlock(UniformInt.of(3, 7), BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PURPLE).strength(3.5F, 4.0F).requiresCorrectToolForDrops()
                    .lightLevel(s -> 5).sound(SoundType.AMETHYST)));

    public static final DeferredBlock<Block> ECHO_CRYSTAL_BLOCK = registerWithItem("echo_crystal_block",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE)
                    .strength(5.0F, 8.0F).requiresCorrectToolForDrops()
                    .lightLevel(s -> 9).sound(SoundType.AMETHYST)));

    public static final DeferredBlock<Block> RIFT_FRAME = registerWithItem("rift_frame",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK)
                    .strength(30.0F, 1200.0F).requiresCorrectToolForDrops()
                    .lightLevel(s -> 4).sound(SoundType.DEEPSLATE_BRICKS)));

    public static final DeferredBlock<RiftPortalBlock> RIFT_PORTAL = BLOCKS.register("rift_portal",
            () -> new RiftPortalBlock(BlockBehaviour.Properties.of().noCollission().noLootTable()
                    .strength(-1.0F).lightLevel(s -> 11).sound(SoundType.GLASS)
                    .pushReaction(net.minecraft.world.level.material.PushReaction.BLOCK)));

    public static final DeferredBlock<RotatedPillarBlock> VOID_LOG = registerWithItem("void_log",
            () -> new RotatedPillarBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK)
                    .strength(2.0F).sound(SoundType.WOOD).ignitedByLava()));

    public static final DeferredBlock<LeavesBlock> VOID_LEAVES = registerWithItem("void_leaves",
            () -> new LeavesBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_MAGENTA)
                    .strength(0.2F).randomTicks().noOcclusion().lightLevel(s -> 6)
                    .sound(SoundType.AZALEA_LEAVES)
                    .isValidSpawn((state, level, pos, type) -> false)
                    .isSuffocating((s, l, p) -> false).isViewBlocking((s, l, p) -> false)));

    public static final DeferredBlock<SovereignAltarBlock> SOVEREIGN_ALTAR = registerWithItem("sovereign_altar",
            () -> new SovereignAltarBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE)
                    .strength(50.0F, 1200.0F).requiresCorrectToolForDrops()
                    .lightLevel(s -> 12).sound(SoundType.AMETHYST)));

    private static <T extends Block> DeferredBlock<T> registerWithItem(String name, Supplier<T> block) {
        DeferredBlock<T> result = BLOCKS.register(name, block);
        ModItems.ITEMS.register(name, () -> new BlockItem(result.get(), new Item.Properties()));
        return result;
    }
}
