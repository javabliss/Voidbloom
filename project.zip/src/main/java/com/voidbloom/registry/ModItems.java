package com.voidbloom.registry;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.item.RiftWandItem;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SwordItem;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(VoidbloomMod.MODID);

    public static final DeferredItem<Item> ECHO_CRYSTAL = ITEMS.registerSimpleItem("echo_crystal");

    // --- Инструменты ---
    public static final DeferredItem<SwordItem> ECHO_SWORD = ITEMS.register("echo_sword",
            () -> new SwordItem(ModTiers.ECHO, new Item.Properties()
                    .attributes(SwordItem.createAttributes(ModTiers.ECHO, 3, -2.4F))));
    public static final DeferredItem<PickaxeItem> ECHO_PICKAXE = ITEMS.register("echo_pickaxe",
            () -> new PickaxeItem(ModTiers.ECHO, new Item.Properties()
                    .attributes(PickaxeItem.createAttributes(ModTiers.ECHO, 1.0F, -2.8F))));
    public static final DeferredItem<AxeItem> ECHO_AXE = ITEMS.register("echo_axe",
            () -> new AxeItem(ModTiers.ECHO, new Item.Properties()
                    .attributes(AxeItem.createAttributes(ModTiers.ECHO, 5.0F, -3.0F))));
    public static final DeferredItem<ShovelItem> ECHO_SHOVEL = ITEMS.register("echo_shovel",
            () -> new ShovelItem(ModTiers.ECHO, new Item.Properties()
                    .attributes(ShovelItem.createAttributes(ModTiers.ECHO, 1.5F, -3.0F))));
    public static final DeferredItem<HoeItem> ECHO_HOE = ITEMS.register("echo_hoe",
            () -> new HoeItem(ModTiers.ECHO, new Item.Properties()
                    .attributes(HoeItem.createAttributes(ModTiers.ECHO, -2.0F, -0.5F))));

    // --- Броня ---
    public static final DeferredItem<ArmorItem> ECHO_HELMET = ITEMS.register("echo_helmet",
            () -> new ArmorItem(ModArmor.ECHO, ArmorItem.Type.HELMET,
                    new Item.Properties().durability(ArmorItem.Type.HELMET.getDurability(38))));
    public static final DeferredItem<ArmorItem> ECHO_CHESTPLATE = ITEMS.register("echo_chestplate",
            () -> new ArmorItem(ModArmor.ECHO, ArmorItem.Type.CHESTPLATE,
                    new Item.Properties().durability(ArmorItem.Type.CHESTPLATE.getDurability(38))));
    public static final DeferredItem<ArmorItem> ECHO_LEGGINGS = ITEMS.register("echo_leggings",
            () -> new ArmorItem(ModArmor.ECHO, ArmorItem.Type.LEGGINGS,
                    new Item.Properties().durability(ArmorItem.Type.LEGGINGS.getDurability(38))));
    public static final DeferredItem<ArmorItem> ECHO_BOOTS = ITEMS.register("echo_boots",
            () -> new ArmorItem(ModArmor.ECHO, ArmorItem.Type.BOOTS,
                    new Item.Properties().durability(ArmorItem.Type.BOOTS.getDurability(38))));

    // --- Уникальный предмет (падает только с босса) ---
    public static final DeferredItem<RiftWandItem> RIFT_WAND = ITEMS.register("rift_wand",
            () -> new RiftWandItem(new Item.Properties().stacksTo(1).durability(320).rarity(Rarity.EPIC)));

    // --- Яйца призыва ---
    public static final DeferredItem<DeferredSpawnEggItem> SHARDLING_SPAWN_EGG = ITEMS.register("shardling_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.SHARDLING, 0x6B3FA0, 0xD9B8FF, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> HOLLOW_STALKER_SPAWN_EGG = ITEMS.register("hollow_stalker_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.HOLLOW_STALKER, 0x14081F, 0xFF3FD0, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> GLOW_PUFF_SPAWN_EGG = ITEMS.register("glow_puff_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.GLOW_PUFF, 0x5AF0E6, 0xFFF59A, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> ECHO_SOVEREIGN_SPAWN_EGG = ITEMS.register("echo_sovereign_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.ECHO_SOVEREIGN, 0x2A0A3F, 0xC77DFF, new Item.Properties()));
}
