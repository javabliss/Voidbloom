package com.voidbloom.registry;

import com.voidbloom.VoidbloomMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, VoidbloomMod.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.voidbloom"))
                    .icon(() -> new ItemStack(ModItems.ECHO_CRYSTAL.get()))
                    .displayItems((params, out) -> {
                        // Блоки
                        out.accept(ModBlocks.ECHO_STONE.get());
                        out.accept(ModBlocks.ECHO_SOIL.get());
                        out.accept(ModBlocks.ECHO_CRYSTAL_ORE.get());
                        out.accept(ModBlocks.ECHO_CRYSTAL_BLOCK.get());
                        out.accept(ModBlocks.RIFT_FRAME.get());
                        out.accept(ModBlocks.VOID_LOG.get());
                        out.accept(ModBlocks.VOID_LEAVES.get());
                        out.accept(ModBlocks.SOVEREIGN_ALTAR.get());
                        // Материалы, инструменты, броня
                        out.accept(ModItems.ECHO_CRYSTAL.get());
                        out.accept(ModItems.ECHO_SWORD.get());
                        out.accept(ModItems.ECHO_PICKAXE.get());
                        out.accept(ModItems.ECHO_AXE.get());
                        out.accept(ModItems.ECHO_SHOVEL.get());
                        out.accept(ModItems.ECHO_HOE.get());
                        out.accept(ModItems.ECHO_HELMET.get());
                        out.accept(ModItems.ECHO_CHESTPLATE.get());
                        out.accept(ModItems.ECHO_LEGGINGS.get());
                        out.accept(ModItems.ECHO_BOOTS.get());
                        out.accept(ModItems.RIFT_WAND.get());
                        // Яйца
                        out.accept(ModItems.SHARDLING_SPAWN_EGG.get());
                        out.accept(ModItems.HOLLOW_STALKER_SPAWN_EGG.get());
                        out.accept(ModItems.GLOW_PUFF_SPAWN_EGG.get());
                        out.accept(ModItems.ECHO_SOVEREIGN_SPAWN_EGG.get());
                    })
                    .build());
}
