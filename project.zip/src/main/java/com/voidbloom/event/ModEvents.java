package com.voidbloom.event;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.block.PortalHelper;
import com.voidbloom.entity.EchoSovereignEntity;
import com.voidbloom.entity.GlowPuffEntity;
import com.voidbloom.entity.HollowStalkerEntity;
import com.voidbloom.entity.ShardlingEntity;
import com.voidbloom.registry.ModBlocks;
import com.voidbloom.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

public class ModEvents {

    @EventBusSubscriber(modid = VoidbloomMod.MODID, bus = EventBusSubscriber.Bus.MOD)
    public static class ModBus {
        @SubscribeEvent
        public static void attributes(EntityAttributeCreationEvent event) {
            event.put(ModEntities.SHARDLING.get(), ShardlingEntity.createAttributes().build());
            event.put(ModEntities.HOLLOW_STALKER.get(), HollowStalkerEntity.createAttributes().build());
            event.put(ModEntities.GLOW_PUFF.get(), GlowPuffEntity.createAttributes().build());
            event.put(ModEntities.ECHO_SOVEREIGN.get(), EchoSovereignEntity.createAttributes().build());
        }

        @SubscribeEvent
        public static void spawnPlacements(RegisterSpawnPlacementsEvent event) {
            event.register(ModEntities.SHARDLING.get(), SpawnPlacementTypes.ON_GROUND,
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkAnyLightMonsterSpawnRules,
                    RegisterSpawnPlacementsEvent.Operation.OR);
            event.register(ModEntities.HOLLOW_STALKER.get(), SpawnPlacementTypes.ON_GROUND,
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkAnyLightMonsterSpawnRules,
                    RegisterSpawnPlacementsEvent.Operation.OR);
            event.register(ModEntities.GLOW_PUFF.get(), SpawnPlacementTypes.ON_GROUND,
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mob::checkMobSpawnRules,
                    RegisterSpawnPlacementsEvent.Operation.OR);
        }
    }

    @EventBusSubscriber(modid = VoidbloomMod.MODID)
    public static class GameBus {
        /** Зажигание портала: ПКМ осколком эха по блоку рамки. */
        @SubscribeEvent
        public static void lightPortal(PlayerInteractEvent.RightClickBlock event) {
            Level level = event.getLevel();
            if (level.isClientSide) return;
            ItemStack held = event.getItemStack();
            if (!held.is(Items.ECHO_SHARD)) return;
            if (!level.getBlockState(event.getPos()).is(ModBlocks.RIFT_FRAME.get())) return;
            if (event.getFace() == null) return;

            BlockPos start = event.getPos().relative(event.getFace());
            if (PortalHelper.tryLight(level, start)) {
                level.playSound(null, start, SoundEvents.RESPAWN_ANCHOR_CHARGE, SoundSource.BLOCKS, 1.0F, 0.7F);
                if (!event.getEntity().getAbilities().instabuild) {
                    held.shrink(1);
                }
                event.setCanceled(true);
            }
        }
    }
}
